-- BMI: execute tudo no Supabase (SQL Editor > New query > Run)
create table public.perfis(uid uuid primary key references auth.users(id) on delete cascade, admin boolean not null default false);
create table public.docs(col text not null, id text not null, data jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now(), primary key(col,id));
alter table public.perfis enable row level security;
alter table public.docs enable row level security;
create function public.is_member() returns boolean language sql security definer set search_path=public stable as $$ select exists(select 1 from public.perfis where uid=auth.uid()) $$;
create function public.is_admin() returns boolean language sql security definer set search_path=public stable as $$ select exists(select 1 from public.perfis where uid=auth.uid() and admin) $$;
create policy perfil_proprio on public.perfis for select to authenticated using (uid=auth.uid());
create policy docs_ler on public.docs for select to authenticated using (public.is_member());
create policy docs_inserir on public.docs for insert to authenticated with check (public.is_member() and (col in ('polos','estados','pendentes','manutencoes','transportes','historico') or public.is_admin()));
create policy docs_alterar on public.docs for update to authenticated using (public.is_member() and (col in ('polos','estados','pendentes','manutencoes','transportes') or public.is_admin())) with check (public.is_member() and (col in ('polos','estados','pendentes','manutencoes','transportes') or public.is_admin()));
create policy docs_apagar on public.docs for delete to authenticated using (public.is_member() and (col in ('polos','estados','pendentes','manutencoes') or public.is_admin()));
create function public.docs_merge(c text, i text, d jsonb) returns void language sql as $$ update public.docs set data = data || d, updated_at = now() where col = c and id = i $$;
grant select, insert, update, delete on public.docs to authenticated;
grant select on public.perfis to authenticated;
grant execute on function public.docs_merge(text, text, jsonb) to authenticated;
alter publication supabase_realtime add table public.docs;

-- Depois de criar os utilizadores (Authentication > Users), dê-lhes acesso:
--   insert into public.perfis(uid, admin) select id, false from auth.users on conflict do nothing;
-- e torne administrador quem quiser (troque o e-mail):
--   update public.perfis set admin = true where uid = (select id from auth.users where email = 'admin@exemplo.com');
