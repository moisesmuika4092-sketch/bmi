// Cole aqui os dados do seu projecto Supabase (ver LEIA-ME.txt, passo 4)
window.SUPABASE_CONFIG={url:"COLE_AQUI",anonKey:"COLE_AQUI"};
