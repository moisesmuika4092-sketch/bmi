// Cole aqui os dados do seu projecto Firebase (ver LEIA-ME.txt, passo 5)
window.FIREBASE_CONFIG={apiKey:"COLE_AQUI",authDomain:"COLE_AQUI",projectId:"COLE_AQUI",appId:"COLE_AQUI"};
